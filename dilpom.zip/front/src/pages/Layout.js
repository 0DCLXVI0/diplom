import { useState } from "react";
import { Outlet } from "react-router-dom";
import NavPanel from "../components/NavPanel";


function Layout() {
  const [sortParametrProblem, setSortParametrProblem] = useState()
  return (
    <>
      <NavPanel setSortParametrProblem={setSortParametrProblem} />
      <Outlet context={[sortParametrProblem]} />
    </>
  );
}

export default Layout;

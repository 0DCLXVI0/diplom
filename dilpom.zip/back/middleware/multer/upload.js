const multer = require("multer");
const storage = require("./storage");

const upload = {
    img: multer({
        storage,
        fileFilter: function (req, file, cb) {
            if (
                file.mimetype ===
                "image/jpeg" ||
                "image/png"
            ) cb(null, true)
            else cb(null, false)
        }
    }),
    img_video: multer({
        storage,
        fileFilter: function (req, file, cb) {
            if (
                file.mimetype ===
                "image/jpeg" ||
                "image/png" ||
                "video/mp4"
            ) cb(null, true)
            else cb(null, false)
        }
    })
}

module.exports = upload
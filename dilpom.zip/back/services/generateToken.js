const jwt = require("jsonwebtoken");

module.exports = function (userId) {
  const accessToken = jwt.sign({ userId }, process.env.JWT_ACCESS_TOKEN);
  const refreshToken = jwt.sign({ userId }, process.env.JWT_REFRESH_TOKEN);
  return { accessToken, refreshToken };
};

const bcryptjs = require("bcryptjs");
const generateToken = require("../services/generateToken");
const { User, IsActivationUser, Problem, Photo, BannedUser } = require("../db/db");
const mailConfirmation = require("../services/nodemailer/mailConfirmation");
const verifyToken = require("../services/verifyToken");

const userController = {
  registration: async function (req, res) {
    try {
      const { email, password } = req.body;
      const candidate = await User.findOne({ where: { email: email } });
      if (candidate)
        return res.status(201).json({
          message: `Пользователь уже существует`,
        });
      const hashPassword = bcryptjs.hashSync(password, 8);
      const user = await User.create({
        email: email,
        password: hashPassword,
        role: 0,
      });
      await User.update(
        { nickname: `user${user.id}` },
        { where: { id: user.id } }
      );
      await mailConfirmation(user.email, user.id);
      const tokens = generateToken(user.id);
      return res
        .status(200)
        .json({
          message: "Пользователь зарегестрирован",
          accessToken: tokens.accessToken,
          role: user.role
        });
    } catch (err) {
      console.log(err);
    }
  },
  authorization: async function (req, res) {
    try {
      const { email, password } = req.body;
      const user = await User.findOne({ where: { email } });
      if (!user)
        return res.status(201).json({ message: `Пользователя не существует` });
      const verifyPassword = bcryptjs.compareSync(password, user.password);
      if (!verifyPassword)
        return res.status(201).json({ message: "Неверный пароль" });
      const tokens = generateToken(user.id);
      return res
        .status(200)
        .json({
          message: "Пользователь авторизирован",
          accessToken: tokens.accessToken,
          role: user.role
        });
    } catch (err) {
      console.log(err);
    }
  },
  activationUser: async function (req, res) {
    try {
      const activationLink = req.params.activationLink;
      const activationUser = await IsActivationUser.findOne({
        where: { activationLink },
      });
      if (!activationUser)
        return res.status(201).json({ message: "Некорректная ссылка" });
      if (activationUser.activation)
        return res
          .status(201)
          .json({ message: "Email пользователя раннее был подтверждён" });
      await activationUser.update({ activation: true });
      return res
        .status(200)
        .json({ message: "Email пользователя подтверждён" });
    } catch (err) {
      console.log(err);
    }
  },
  logout: async function (req, res) {
    try {
      return res
        .status(200)
        .clearCookie("refreshToken")
        .json({ message: "Пользователь вышел из системы" });
    } catch (err) {
      console.log(err);
    }
  },
  addAvatar: async function (req, res) {
    try {
      const file = req.file;
      if (!file)
        return res.status(201).json({ message: "Ошибка при загрузке файла" });
      const { userId } = verifyToken(req);
      const avatar = await Photo.create({ path: file.filename });
      await User.update(
        {
          avatar: avatar.path
        },
        { where: { id: userId } }
      )
      return res.status(200).json({ message: "Аватар обновлён", static: avatar.path });
    } catch (err) {
      console.log(err);
    }
  },
  rename: async function (req, res) {
    const { nickname } = req.body;
    const { userId } = verifyToken(req);
    await User.update({ nickname }, { where: { id: userId } });
    return res.status(200).json({ message: "Имя изменено" });
  },
  getUser: async function (req, res) {
    try {
      const { userId } = verifyToken(req);
      const user = await User.findByPk(userId, {
        include: [
          {
            model: IsActivationUser,
            attributes: ["activation", "activationLink"]
          },
          {
            model: Problem,
            attributes: ["tittle", "date", "id"],
            include: [
              { model: Photo, attributes: ["path"] }
            ]
          }
        ]
      });
      return res.status(200).json(user);
    } catch (err) {
      console.log(err);
    }
  },
  getUsers: async function (req, res) {
    try {
      const users = await User.findAll({ where: { banned: false } })
      return res.status(200).json(users)
    } catch (err) {
      console.log(err)
    }
  },
  banUser: async function (req, res) {
    try {
      const { userId: adminId } = verifyToken(req)
      const { userId, reason } = req.body
      if (adminId === userId)
        return res.status(201).json({ message: "Вы не можете забанить самого себя" })
      await User.update({ banned: true }, { where: { id: userId } })
      await BannedUser.create({ userId, reason })
      return res.status(200).json({ message: "Пользователь забанен" })
    } catch (err) {
      console.log(err)
    }
  },
  unbanUser: async function (req, res) {
    try {
      const { userId } = req.body
      await User.update({ banned: false }, { where: { id: userId } })
      await BannedUser.destroy({ where: { userId } })
      return res.status(200).json({ message: "Пользователь разбанен" })
    } catch (err) {
      console.log(err)
    }
  },
  getBannedUsers: async function (req, res) {
    try {
      const users = await User.findAll({
        where: { banned: true },
        attributes: ["id", "email"],
        include: [
          { model: BannedUser, attributes: ["reason"] }
        ]
      })
      return res.status(200).json(users)
    } catch (err) {
      console.log(err)
    }
  }
};

module.exports = userController;

const { IsActivationUser } = require("../db/db");
const verifyToken = require("../services/verifyToken");

module.exports = async function (req, res, next) {
  try {
    const {userId} = verifyToken(req);
    const activationUser = await IsActivationUser.findByPk(userId)
    if (!activationUser.activation)
      return res
        .status(201)
        .send({ message: "У пользователя не подтверждён email" });
    next();
  } catch (err) {
    console.log(err);
  }
};

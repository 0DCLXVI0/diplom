import { $host, $hostAuth } from "./instances"

async function authorizationAPI({ email, password }) {
    const res = await $host.post("/user/authorization", { email, password })
    return res
}

async function registrationAPI({ email, password }) {
    const res = await $host.post("/user/registration", { email, password })
    return res
}

async function getUserAPI() {
    const res = await $hostAuth.get("/user/getUser")
    return res
}

async function renameUserAPI(nickname) {
    const res = await $hostAuth.put("/user/rename", { nickname })
    return res
}

async function addAvatarAPI(img) {
    const formData = new FormData()
    formData.append("avatar", img)
    const res = await $hostAuth.put("/user/addAvatar", formData,
        {
            headers: {
                "Content-Type": "multipart/form-data"
            },
        })
    return res
}

async function logoutAPI() {
    const res = await $hostAuth.get("/user/logout")
    return res
}

async function getUsersAPI() {
    const res = await $hostAuth.get("/user/getUsers")
    return res
}

async function banUserAPI(userId, reason) {
    const res = await $hostAuth.post("/user/banUser", { userId, reason })
    return res
}

async function unbanUserAPI(userId) {
    const res = await $hostAuth.post("/user/unbanUser", { userId })
    return res
}

async function getBannedUsersAPI() {
    const res = await $hostAuth.get("/user/getBannedUsers")
    return res
}

export {
    authorizationAPI,
    registrationAPI,
    getUserAPI,
    renameUserAPI,
    addAvatarAPI,
    logoutAPI,
    getUsersAPI,
    banUserAPI,
    unbanUserAPI,
    getBannedUsersAPI
}
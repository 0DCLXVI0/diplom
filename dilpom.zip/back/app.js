require("dotenv").config();
const fs = require("fs");
const cors = require("cors");
const express = require("express");
const app = express();
const { sequelize } = require("./db/db");
const bodyParser = require("body-parser");
const cookieParser = require("cookie-parser");
const swaggerUi = require("swagger-ui-express");
const userRouter = require("./routes/userRouter");
const roleRouter = require("./routes/roleRouter");
const problemRouter = require("./routes/problemRouter");
const path = require("path");

async function connection() {
  try {
    await sequelize.authenticate();
    console.log("Connection has been established successfully.");
  } catch (error) {
    console.error("Unable to connect to the database:", error);
  }
}

const openapi = JSON.parse(fs.readFileSync("./openapi.json"));

app.use(cookieParser('secret key'));
app.use(bodyParser.json());
app.use(express.static(path.join("static")))
app.use(cors());
app.use("/user", userRouter);
app.use("/role", roleRouter);
app.use("/problem", problemRouter);
app.use(
  "/api-docs",
  swaggerUi.serve,
  swaggerUi.setup(openapi, { explorer: true })
);

app.listen(process.env.PORT, () => connection());

const userRouter = require("express").Router();
const { body } = require("express-validator");
const userController = require("../controllers/userController");
const authVerification = require("../middleware/authVerification");
const checkValidation = require("../middleware/checkValidation");
const { img } = require("../middleware/multer/upload");
const roleVerification = require("../middleware/roleVerification");

userRouter.post(
  "/registration",
  [
    body("email").isEmail().not().isEmpty(),
    body("password").isLength({ min: 6, max: 20 }).not().isEmpty(),
    checkValidation,
  ],
  userController.registration
);

userRouter.post(
  "/authorization",
  [
    body("email").isEmail().not().isEmpty(),
    body("password").isLength({ min: 6, max: 20 }).not().isEmpty(),
    checkValidation,
  ],
  userController.authorization
);

userRouter.get(
  "/activationUser/:activationLink",
  authVerification,
  userController.activationUser
);

userRouter.get("/logout", authVerification, userController.logout);

userRouter.put(
  "/addAvatar",
  [
    authVerification,
    img.single("avatar")
  ],
  userController.addAvatar
);

userRouter.put(
  "/rename",
  [body("nickname").not().isEmpty(), checkValidation],
  userController.rename
);

userRouter.get("/getUser", authVerification, userController.getUser);

userRouter.get("/getUsers",
  [authVerification, roleVerification(1)], userController.getUsers)

userRouter.post("/banUser",
  [
    authVerification,
    roleVerification(1),
    body("userId").not().isEmpty(),
    body("reason").not().isEmpty(),
    checkValidation
  ],
  userController.banUser)

userRouter.post("/unbanuser",
  [
    authVerification,
    roleVerification(1),
    body("userId").not().isEmpty(),
    checkValidation
  ]
  , userController.unbanUser)

userRouter.get("/getBannedUsers", [authVerification, roleVerification(1)], userController.getBannedUsers)

module.exports = userRouter;

const { User } = require("../db/db");
const verifyToken = require("../services/verifyToken");

module.exports = roleController;

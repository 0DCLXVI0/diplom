import { Card } from "react-bootstrap"
import { useNavigate } from "react-router-dom"
import styles from "../modules/problemCard.module.scss"
import defaultPhoto from "../images/photo.svg"

function ProblemCard(props) {
    const date = props.date.split("T")[0]
    const time = props.date.split("T")[1].split(".")[0]

    const navigate = useNavigate()

    return (
        <Card className={styles.card} onClick={() =>
            navigate("/problem/getProblem/" + props.id + "/" + props.edit)
        }>
            <Card.Img
                src={props.photo
                    ? "http://localhost:3008/" + props.photo.path
                    : defaultPhoto} />
            <Card.Body>
                <Card.Title><h3><strong>{props.tittle}</strong></h3></Card.Title>
                <Card.Body>
                    <p>Автор: {props.nickname}</p>
                    <p>Дата: {date + " " + time}</p>
                </Card.Body>
                <Card.Text>
                    {props.description}
                </Card.Text>
            </Card.Body>
        </Card>
    )
}

export default ProblemCard
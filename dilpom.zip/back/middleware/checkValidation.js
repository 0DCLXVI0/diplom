const { validationResult } = require("express-validator");

module.exports = async function (req, res, next) {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(201).send(errors);
    next();
  } catch (err) {
    console.log(err);
  }
};

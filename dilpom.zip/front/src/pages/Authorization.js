import RegistrationForm from "../components/RegistrationForm"
import { authorizationAPI } from "../http/userAPI"

function Authorization() {
    return <RegistrationForm tittle="Авторизация" callback={authorizationAPI} />
}

export default Authorization
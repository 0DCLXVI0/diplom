import { useState } from 'react';
import { CloseButton, Form, ListGroup } from 'react-bootstrap';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import { Row, Col } from "react-bootstrap"
import { useMutation, useQueryClient } from 'react-query';
import { addProblemAPI } from '../http/problemAPI';

function ModalAddProblem({ show, setShow }) {
    const queryClient = useQueryClient()
    const [fields, setFields] = useState({ tittle: "", description: "", files: [] })

    const { mutate: addProblem } = useMutation("addProblem",
        async (fields) => await addProblemAPI(fields), {
        onSuccess() {
            queryClient.invalidateQueries("userData")
            close()
        }
    }
    )

    function addFile(e) {
        const file = e.target.files[0]
        setFields({
            ...fields, files:
                [...fields.files, { id: fields.files.length, name: file.name, file }]
        })
    }

    function deleteFile(i) {
        setFields(fields => ({
            ...fields, files:
                fields.files.filter((value, index) => i !== index)
        }))
    }

    function close() {
        setFields({ tittle: "", description: "", files: [] })
        setShow(false)
    }

    return (
        <Modal show={show}>
            <Modal.Header>
                <Modal.Title>Добавление проблемы</Modal.Title>
            </Modal.Header>

            <Modal.Body>
                <Form>
                    <Form.Group className="mb-3">
                        <Form.Label>Заголовок</Form.Label>
                        <Form.Control
                            value={fields.tittle}
                            onChange={e => setFields({ ...fields, tittle: e.target.value })}
                            type="text" />
                    </Form.Group>

                    <Form.Group className="mb-3 d-flex flex-column">
                        <Form.Label>Описание</Form.Label>
                        <textarea value={fields.description}
                            onChange={e =>
                                setFields({ ...fields, description: e.target.value })
                            } />
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Control
                            onChange={addFile}
                            multiple
                            type="file" />
                    </Form.Group>
                </Form>
                <Row>
                    {fields.files.map((file, index) =>
                        <Col
                            className="d-flex align-items-center justify-content-between border rounded flex-grow-0"
                            key={file.id}>
                            {file.name}
                            <CloseButton onClick={() => deleteFile(index)} />
                        </Col>)}
                </Row>
            </Modal.Body>

            <Modal.Footer>
                <Button variant="secondary" onClick={close}>Отменить</Button>
                <Button variant="primary" type='submit' onClick={() => addProblem(fields)
                }>Добавить</Button>
            </Modal.Footer>
        </Modal>
    );
}

export default ModalAddProblem;
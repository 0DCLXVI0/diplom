const transporter = require("./transporter");
const uuid = require("uuid");
const { IsActivationUser } = require("../../db/db");

module.exports = async function (email, id) {
  try {
    const activationLink = uuid.v4();
    const mailOptions = {
      from: process.env.EMAIL,
      to: email,
      subject: "Подтверждение почты",
      html: `
            <div>
                <h1>Для активации перейдите по ссылке:</h1>
                <a href="${process.env.API_URL}/user/activationUser/${activationLink}">${process.env.API_URL}/user/activationUser/${activationLink}</a>
            </div>
          `,
    };
    await IsActivationUser.create({ userId: id, activationLink });
    await transporter.sendMail(mailOptions);
  } catch (err) {
    console.log(err)
  }
};

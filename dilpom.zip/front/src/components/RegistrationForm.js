import { useContext, useState } from 'react';
import { Alert, Button, Container, Form } from 'react-bootstrap';
import { useMutation } from 'react-query';
import { Link, useNavigate } from 'react-router-dom';
import { Context } from '../context';
import { getUserAPI } from '../http/userAPI';

function RegistrationForm({ callback, tittle }) {
    const [userValue, setUserValue] = useState({ email: "", password: "" })
    const [successAlertShow, setSuccessAlertShow] = useState(false)
    const [dangerAlertShow, setDangerAlertShow] = useState(false)
    const [message, setMessage] = useState("")
    const { setIsUserAuth, setUserARole } = useContext(Context)
    async function sendValueAUser(e) {
        e.preventDefault()
        const res = await callback(userValue)
        switch (res.request.status) {
            case 200:
                setSuccessAlertShow(true)
                const data = res.data
                localStorage.setItem("accessToken", data.accessToken)
                setIsUserAuth(true)
                localStorage.setItem("userARole", parseInt(data.role))
                setUserARole(data.role)
                break
            case 201:
                setDangerAlertShow(true)
                setMessage(res.data.message)
                break
        }
    }

    return (
        <Container className='w-50'>
            <Alert
                className='mt-2'
                variant='success'
                show={successAlertShow}>
                Вы успешно {tittle === "Регистрация" ? "зарегестрировались" : "авторизировались"}
                {", "} перейти на {" "}
                <Alert.Link as={Link} to="/problem/getProblems">проблемы</Alert.Link>
                {" "} или в {" "}
                <Alert.Link as={Link} to="/user/personalAccount">личный кабинет</Alert.Link>
                ?
            </Alert>
            <Alert
                className='mt-2'
                variant='danger'
                show={dangerAlertShow}>
                {message}
            </Alert>
            {!successAlertShow
                ?
                <Form onSubmit={sendValueAUser}>
                    <h1>{tittle}</h1>
                    <Form.Group className="mb-3">
                        <Form.Label>Email</Form.Label>
                        <Form.Control value={userValue.email}
                            onChange={(e) => setUserValue({ ...userValue, email: e.target.value })} type="email" />
                    </Form.Group>
                    <Form.Group className="mb-3">
                        <Form.Label>Пароль</Form.Label>
                        <Form.Control value={userValue.password}
                            onChange={(e) => setUserValue({ ...userValue, password: e.target.value })} type="password" />
                    </Form.Group>
                    <Button
                        type="submit">
                        Отправить
                    </Button>
                </Form>
                : null}
        </Container>
    );
}

export default RegistrationForm;
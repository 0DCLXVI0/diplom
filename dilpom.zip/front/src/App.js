import { createBrowserRouter, RouterProvider } from "react-router-dom";
import Layout from "./pages/Layout";
import Home from "./pages/Home";
import Registration from "./pages/Registration";
import Authorization from "./pages/Authorization";
import PersonalAccount from "./pages/PersonalAccount";
import Problems from "./pages/Problems";
import Problem from "./pages/Problem";
import { QueryClient, QueryClientProvider } from 'react-query'
import { ContextProvider } from "./context";
import AdminPanel from "./pages/AdminPanel";

const queryClient = new QueryClient()

const router = createBrowserRouter(
    [
        {
            path: "/",
            element: < Layout />,
            children: [
                { path: "/", element: <Home /> },
                { path: "/user/registration", element: <Registration /> },
                { path: "/user/authorization", element: <Authorization /> },
                { path: "/user/personalAccount", element: <PersonalAccount /> },
                { path: "/problem/getProblems", element: <Problems /> },
                { path: "/problem/getProblem/:problemId/:edit", element: <Problem /> },
                { path: "/user/adminPanel", element: <AdminPanel /> }
            ]

        },
    ]
);

function App() {
    return (
        <QueryClientProvider client={queryClient}>
            <ContextProvider>
                <RouterProvider router={router} />
            </ContextProvider>
        </QueryClientProvider>
    )
}

export default App;
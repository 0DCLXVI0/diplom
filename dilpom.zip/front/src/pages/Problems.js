import { Col, Container, Row } from "react-bootstrap"
import ProblemCard from "../components/ProblemCard"
import CustomSpinner from "../components/CustomSpinner"
import { getProblemsAPI } from "../http/problemAPI"
import { useQuery, useQueryClient } from 'react-query'
import { useOutletContext } from "react-router-dom"
import { useEffect } from "react"

function Problems() {
    const queryClient = useQueryClient()
    const [sortParametrProblem] = useOutletContext()
    const { isLoading, error, data: problems } = useQuery(
        'problemsData',
        async () => {
            const res = await getProblemsAPI()
            return res.data
        }
    )

    useEffect(() => {
        switch (sortParametrProblem) {
            case "tittle":
                queryClient.setQueryData("problemsData", problems.sort((a, b) => a.tittle.localeCompare(b.tittle)))
                break
            case "date":
                queryClient.setQueryData("problemsData", problems.sort((a, b) => a.date < b.date))
                break
            default:
                break
        }
    }, [sortParametrProblem])

    return (
        <>
            {error
                ? <p>{error.message}</p>
                :
                (
                    isLoading
                        ? <CustomSpinner />
                        : <Container>
                            <Row xs={1} md={2}>
                                {problems.map(problem =>
                                    <Col key={problem.id}>
                                        <ProblemCard
                                            key={problem.id}
                                            id={problem.id}
                                            photo={problem.Photos.length > 0
                                                ? problem.Photos[0]
                                                : null
                                            }
                                            tittle={problem.tittle}
                                            nickname={problem.User.nickname}
                                            description={problem.description}
                                            date={problem.date}
                                            edit={false}
                                        />
                                    </Col>
                                )}
                            </Row>
                        </Container>
                )
            }
        </>
    )
}

export default Problems
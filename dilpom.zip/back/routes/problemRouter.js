const problemRouter = require("express").Router();
const { body } = require("express-validator");
const problemController = require("../controllers/problemController");
const authVerification = require("../middleware/authVerification");
const emailVerification = require("../middleware/emailVerification");
const checkValidation = require("../middleware/checkValidation")
const { img_video } = require("../middleware/multer/upload");

problemRouter.post(
  "/addProblem",
  [
    authVerification,
    emailVerification,
    img_video.fields([
      { name: "file" },
      { name: "tittle" },
      { name: "description" }
    ]),
    body("tittle").not().isEmpty(),
    body("description").not().isEmpty(),
    checkValidation,
  ],
  problemController.addProblem
);

problemRouter.get(
  "/getProblems",
  problemController.getProblems
);

problemRouter.get("/getProblem/:problemId", problemController.getProblem);

module.exports = problemRouter;

import { useContext, useState } from 'react';
import { Button, Nav, Navbar, NavDropdown } from 'react-bootstrap';
import { BoxArrowLeft, Newspaper, PersonAdd, PersonCheck, PersonVcard, JournalCode } from 'react-bootstrap-icons';
import { NavLink, useLocation, useNavigate } from 'react-router-dom';
import { Context } from '../context';
import { logoutAPI } from '../http/userAPI';
import styles from "../modules/navPanel.module.scss"

function NavPanel({ setSortParametrProblem }) {
    const { isUserAuth, setIsUserAuth, setUserARole, userARole } = useContext(Context)
    const [activeItem, setActiveItem] = useState("")

    const location = useLocation()
    const navigate = useNavigate()

    function exit() {
        logoutAPI()
        localStorage.removeItem("accessToken")
        setIsUserAuth(false)
        localStorage.removeItem("userARole")
        setUserARole(0)
        navigate("/")
    }

    return (
        <Navbar bg="light" expand="lg">
            <Navbar.Brand as={NavLink} to="/">Проблем.NET</Navbar.Brand>
            <Navbar.Toggle aria-controls="basic-navbar-nav" />
            <Navbar.Collapse id="basic-navbar-nav">
                <Nav className="me-auto">
                    {location.pathname !== "/problem/getProblems"
                        ?
                        <Nav.Link className={styles.link} as={NavLink} to="/problem/getProblems">
                            <Newspaper />
                            Проблемы
                        </Nav.Link>
                        :
                        <NavDropdown
                            title="Сортировка по:"
                        >
                            <NavDropdown.Item
                                onClick={() => {
                                    setActiveItem("date")
                                    setSortParametrProblem("date")
                                }}
                                active={activeItem === "date"}>
                                по дате
                            </NavDropdown.Item>
                            <NavDropdown.Item
                                onClick={() => {
                                    setActiveItem("tittle")
                                    setSortParametrProblem("tittle")
                                }}
                                active={activeItem === "tittle"}>
                                по заголовку
                            </NavDropdown.Item>
                        </NavDropdown>
                    }
                    {location.pathname === "/user/personalAccount" &&
                        userARole === 1
                        ? <Nav.Link className={styles.link} as={NavLink} to="/user/adminPanel">
                            <JournalCode />
                            Панель администратора
                        </Nav.Link>
                        : null
                    }
                    {isUserAuth && location.pathname !== "/user/personalAccount"
                        ?
                        <Nav.Link className={styles.link} as={NavLink} to="/user/personalAccount">
                            <PersonVcard />
                            Личный кабинет
                        </Nav.Link>
                        : !isUserAuth
                            ?
                            <>
                                <Nav.Link className={styles.link} as={NavLink} to="/user/registration">
                                    <PersonAdd />
                                    Регистрация
                                </Nav.Link>
                                <Nav.Link className={styles.link} as={NavLink} to="/user/authorization">
                                    <PersonCheck />
                                    Авторизация
                                </Nav.Link>
                            </>
                            : null
                    }
                </Nav>
                {location.pathname === "/user/personalAccount"
                    ? <Button className={styles.link} variant='danger' onClick={exit}>
                        <BoxArrowLeft color='white' />
                        Выход
                    </Button>
                    : null
                }
            </Navbar.Collapse>
        </Navbar>
    );
}

export default NavPanel;
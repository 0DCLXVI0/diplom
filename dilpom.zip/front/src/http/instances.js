import axios from "axios";

const baseURL = "http://localhost:3008"

const $host = axios.create({ baseURL })

const $hostAuth = axios.create({
    baseURL,
    headers: { "Authorization": "Bearer " + localStorage.getItem("accessToken") }
})

export {
    $host,
    $hostAuth
}
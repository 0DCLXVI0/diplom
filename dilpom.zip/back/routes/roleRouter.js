const roleRouter = require("express").Router();
const { body } = require("express-validator");
const authVerification = require("../middleware/authVerification");
const checkValidation = require("../middleware/checkValidation");

module.exports = roleRouter;

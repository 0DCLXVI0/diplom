import { useState } from "react"
import { Badge, Button, ButtonGroup, Col, Container, Form, Image, Row } from "react-bootstrap"
import CustomSpinner from "../components/CustomSpinner"
import ModalAddProblem from "../components/ModalAddProblem"
import { addAvatarAPI, getUserAPI, renameUserAPI } from "../http/userAPI"
import { useMutation, useQuery, useQueryClient } from 'react-query'
import { Check, EnvelopeCheck, EnvelopeX, PersonBoundingBox, X } from "react-bootstrap-icons"
import ProblemCard from "../components/ProblemCard"
import styles from "../modules/personalAccount.module.scss"

function PersonalAccount() {
    const queryClient = useQueryClient()
    const [show, setShow] = useState(false)
    const [nickname, setNickname] = useState("")
    const [isEditNickname, setIsEditNickname] = useState(false)

    const { isLoading, error, data: user } = useQuery("userData",
        async () => {
            const res = await getUserAPI()
            return res.data
        }
    )
    const { mutate: renameUser } = useMutation("renameUser",
        async nickname => await renameUserAPI(nickname),
        {
            onSuccess() {
                queryClient.invalidateQueries("userData")
                setNickname("")
                setIsEditNickname(false)
            }
        }
    )

    const { mutate: addAvatar } = useMutation("addAvatar",
        (avatar) => addAvatarAPI(avatar), {
        onSuccess() {
            queryClient.invalidateQueries("userData")
        }
    })

    return (
        <>
            {error
                ? <p>{error.message}</p>
                :
                (
                    isLoading
                        ? <CustomSpinner />
                        :
                        <Container>
                            <ModalAddProblem show={show} setShow={setShow} />
                            {/* <Col className={styles.col}>
                                    {user.avatar
                                        ? <Image
                                            rounded={true}
                                            className={styles.avatar}
                                            src={"http://localhost:3008/" + user.avatar} alt="avatar" />
                                        : <PersonBoundingBox className={styles.avatar} />}
                                </Col> */}
                            {/* <Col className={styles.col}> */}
                            {/* <Form className="min-vw-content">
                                        <Form.Label className={styles.label}>
                                            <span>Изменить аватар</span>
                                            <Form.Control type="file" onChange={e => addAvatar(e.target.files[0])} />
                                        </Form.Label>
                                    </Form> */}
                            <Row className={styles.row}>
                                {user.avatar
                                    ? <Image
                                        rounded={true}
                                        className={styles.avatar}
                                        src={"http://localhost:3008/" + user.avatar} alt="avatar" />
                                    : <PersonBoundingBox className={styles.avatar} />}
                                <Form className={styles.form}>
                                    <Form.Label className={styles.label}>
                                        <Form.Control
                                            className="outline-0 opacity-0"
                                            type="file"
                                            onChange={e => addAvatar(e.target.files[0])} />
                                    </Form.Label>
                                </Form>
                                {isEditNickname
                                    ?
                                    <div className="d-flex">
                                        <Form.Control
                                            onChange={(e) => setNickname(e.target.value)}
                                            value={nickname}
                                        />
                                        <ButtonGroup>
                                            <Button
                                                disabled={nickname.length === 0 ? true : false}
                                                variant="success"
                                                onClick={() => renameUser(nickname)}>
                                                <Check />
                                            </Button>
                                            <Button variant="danger"
                                                onClick={() => {
                                                    setNickname("")
                                                    setIsEditNickname(false)
                                                }}>
                                                <X />
                                            </Button>
                                        </ButtonGroup>
                                    </div>
                                    : <div className={styles.row}>
                                        <span className="h2">{user.nickname}</span>
                                        <Button className="ms-2" onClick={() => setIsEditNickname(true)}>Изменить никнейм</Button>
                                    </div>
                                }
                            </Row>
                            <div className={styles.row}>
                                <span className="h2">{user.email}</span>
                                {user.isActivationUser.activation
                                    ? <Badge pill bg="success"><EnvelopeCheck /></Badge>
                                    : <Badge pill bg="danger"><EnvelopeX /></Badge>}
                            </div>
                            {user.isActivationUser.activation
                                ?
                                <>
                                    <div className="d-flex justify-content-center my-2">
                                        <Button onClick={() => setShow(true)}>Добавить проблему</Button>
                                    </div>
                                    <div>
                                        <h1>Ваши проблемы:</h1>
                                        <Row md={2}>
                                            {user.Problems.map(problem =>
                                                <Col key={problem.id}>
                                                    <ProblemCard
                                                        className="w-50"
                                                        id={problem.id}
                                                        photo={problem.Photos.length > 0
                                                            ? problem.Photos[0]
                                                            : null
                                                        }
                                                        tittle={problem.tittle}
                                                        nickname={user.nickname}
                                                        description={problem.description}
                                                        date={problem.date}
                                                        edit={true}
                                                    />
                                                </Col>
                                            )}
                                        </Row>
                                    </div>
                                </>
                                : null}
                        </Container>
                )
            }
        </>
    )
}

export default PersonalAccount
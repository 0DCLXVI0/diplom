import { $host, $hostAuth } from "./instances"

async function addProblemAPI(fields) {
    const { tittle, description, files } = fields
    const formData = new FormData()
    formData.append("tittle", tittle)
    formData.append("description", description)
    files.forEach(file => formData.append("file", file.file))
    const res = await $hostAuth.post("/problem/addProblem", formData,
        {
            headers: {
                "Content-Type": "multipart/form-data"
            },
        })
    return res
}

async function getProblemsAPI() {
    const res = await $host.get("/problem/getProblems")
    return res
}

async function getProblemAPI(problemId) {
    const res = await $host.get("/problem/getProblem/" + problemId)
    return res
}

export {
    addProblemAPI,
    getProblemsAPI,
    getProblemAPI,
}
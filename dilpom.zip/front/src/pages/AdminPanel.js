import { useState } from "react"
import { Button, Col, Modal, Row, Spinner } from "react-bootstrap"
import { useMutation, useQuery, useQueryClient } from "react-query"
import { banUserAPI, getBannedUsersAPI, getUsersAPI, unbanUserAPI } from "../http/userAPI"
import styles from "../modules/adminPanel.module.scss"

function AdminPanel() {
    const [show, setShow] = useState(false)
    const [reason, setReason] = useState("")
    const [userId, setUserId] = useState(undefined)
    const queryClient = useQueryClient()

    const { isLoading: isLoadingUsers, errorUsers, data: users } = useQuery("usersData",
        async () => {
            const res = await getUsersAPI()
            return res.data
        }
    )

    const { isLoading: isLoadingBannedUsers, errorBannedUsers, data: bannedUsers } = useQuery("bannedUsersData",
        async () => {
            const res = await getBannedUsersAPI()
            return res.data
        }
    )

    const { mutate: banUser } = useMutation("banUser",
        async (userId) => await banUserAPI(userId, reason), {
        onSuccess() {
            queryClient.invalidateQueries("usersData")
            queryClient.invalidateQueries("bannedUsersData")
        }
    })

    const { mutate: unbanUser } = useMutation("unbanUser",
        async (userId) => await unbanUserAPI(userId), {
        onSuccess() {
            queryClient.invalidateQueries("usersData")
            queryClient.invalidateQueries("bannedUsersData")
        }
    })

    return (
        <>
            <Modal show={show}>
                <Modal.Header>
                    <Modal.Title>Причина</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <textarea
                        className="w-100"
                        value={reason}
                        onChange={(e) => setReason(e.target.value)}
                    >
                    </textarea>
                </Modal.Body>
                <Modal.Footer>
                    <Button
                        onClick={() => setShow(false)}
                        variant="secondary">
                        Отменить
                    </Button>
                    <Button
                        onClick={() => {
                            banUser(userId, reason)
                            setReason("")
                            setShow(false)
                        }}
                        variant="primary">
                        Сохранить
                    </Button>
                </Modal.Footer>
            </Modal>
            {errorUsers
                ? <p>{errorUsers.message}</p>
                : isLoadingUsers
                    ?
                    <Spinner animation="border" role="status">
                        <span className="visually-hidden"></span>
                    </Spinner>
                    :
                    <>
                        <p className="h2">Таблица пользователей</p>
                        <Row style={{ borderCollapse: "collapse" }}>
                            <Col md={1} className={styles.cell}><p>ID</p></Col>
                            <Col md={4} className={styles.cell}><p>email</p></Col>
                            <Col className={styles.cell}><p>nickname</p></Col>
                            <Col className={styles.cell}><p>role</p></Col>
                            <Col md={2} className={styles.cell}></Col>
                        </Row>
                        {users.map(user =>
                            <Row style={{ borderCollapse: "collapse" }} key={user.id}>
                                <Col md={1} className={styles.cell}>{user.id}</Col>
                                <Col md={4} className={styles.cell}>{user.email}</Col>
                                <Col className={styles.cell}>{user.nickname}</Col>
                                <Col className={styles.cell}>{user.role}</Col>
                                <Col md={2} className={styles.cell}>
                                    <Button variant="danger" onClick={() => {
                                        setShow(true)
                                        setUserId(user.id)
                                    }}>
                                        Заблокировать
                                    </Button>
                                </Col>
                            </Row>
                        )}
                    </>
            }
            {errorBannedUsers
                ? <p>{errorBannedUsers.message}</p>
                : isLoadingBannedUsers
                    ?
                    <Spinner animation="border" role="status">
                        <span className="visually-hidden"></span>
                    </Spinner>
                    :
                    <>
                        <p className="h2 mt-3">Таблица заблокированных пользователей</p>
                        <Row style={{ borderCollapse: "collapse" }}>
                            <Col md={1} className={styles.cell}><p>ID</p></Col>
                            <Col md={4} className={styles.cell}><p>email</p></Col>
                            <Col className={styles.cell}><p>причина</p></Col>
                            <Col md={2} className={styles.cell}></Col>
                        </Row>
                        {bannedUsers.map(user =>
                            <Row style={{ borderCollapse: "collapse" }} key={user.id}>
                                <Col md={1} className={styles.cell}>{user.id}</Col>
                                <Col md={4} className={styles.cell}>{user.email}</Col>
                                <Col className={styles.cell}>{user.BannedUser.reason}</Col>
                                <Col md={2} className={styles.cell}>
                                    <Button onClick={() => unbanUser(user.id)} variant="success">
                                        Разблокировать
                                    </Button>
                                </Col>
                            </Row>
                        )}
                    </>
            }
        </>
    )
}

export default AdminPanel
import { useState } from "react"
import { Col, Container, Image, Row, Spinner } from "react-bootstrap"
import { useQuery } from "react-query"
import { useParams } from "react-router-dom"
import { getProblemAPI } from "../http/problemAPI"
import styles from "../modules/problem.module.scss"

function Problem() {
    const params = useParams()
    const [mainPhoto, setMainPhoto] = useState({})

    const { isLoading, error, data: problem } = useQuery("problemData",
        async () => {
            const res = await getProblemAPI(params.problemId)
            const data = res.data
            return data
        }, {
        onSuccess(data) {
            if (data.Photos.length > 0)
                setMainPhoto({ id: data.Photos[0].id, path: data.Photos[0].path })
        }
    }
    )

    return (
        <>
            {error
                ? <p>{error.message}</p>
                :
                isLoading
                    ?
                    <Spinner animation="border" role="status">
                        <span className="visually-hidden"></span>
                    </Spinner>
                    :
                    <Container>
                        <h1>{problem.tittle}</h1>
                        {problem.Photos.length > 0
                            ?
                            <Row>
                                <Col className="d-flex justify-content-center">
                                    <Image
                                        rounded={true}
                                        className={styles.mainPhoto}
                                        src={"http://localhost:3008/" + mainPhoto.path}
                                        alt="" />
                                </Col>
                                <Col>
                                    <Row xs={2} md={4}>
                                        {problem.Photos.map(photo =>
                                            <Col className="d-flex justify-content-center" key={photo.id}>
                                                <Image rounded={true}
                                                    style={{
                                                        filter:
                                                            photo.id === mainPhoto.id
                                                                ? "brightness(60%)"
                                                                : "brightness(100%)"
                                                    }}
                                                    className={styles.photo}
                                                    onClick={() =>
                                                        setMainPhoto({ id: photo.id, path: photo.path })
                                                    }
                                                    src={"http://localhost:3008/" + photo.path}
                                                    alt="" />
                                            </Col>
                                        )}
                                    </Row>
                                    <Row className="d-flex flex-column">
                                        <p className="h1">Описание:</p>
                                        <div className={styles.description}>
                                            <p>{problem.description}</p>
                                        </div>
                                    </Row>
                                    <Row className="d-flex justify-content-end">
                                        <p className="h2"><em>{problem.User.nickname}</em></p>
                                    </Row>
                                </Col>
                            </Row>
                            :
                            <>
                                <Row className="d-flex flex-column">
                                    <p className="h1">Описание:</p>
                                    <div className={styles.description}>
                                        <p>{problem.description}</p>
                                    </div>
                                </Row>
                                <Row className="d-flex justify-content-end">
                                    <p className="h2"><em>{problem.User.nickname}</em></p>
                                </Row>
                            </>
                        }
                    </Container>
            }
        </>
    )
}

export default Problem
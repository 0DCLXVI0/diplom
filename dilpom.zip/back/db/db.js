const { Sequelize, DataTypes } = require("sequelize");

const sequelize = new Sequelize(
  process.env.DATABASE,
  process.env.LOGIN,
  process.env.PASSWORD,
  {
    dialect: process.env.DIALECT,
    host: process.env.HOST,
    define: {
      timestamps: false,
    },
  }
);

async function Synchronizing() {
  await sequelize.sync({ force: true });
}

const User = sequelize.define("User", {
  email: { type: DataTypes.STRING },
  password: { type: DataTypes.STRING },
  avatar: { type: DataTypes.STRING, defaultValue: null },
  nickname: { type: DataTypes.STRING },
  role: { type: DataTypes.STRING },
  banned: { type: DataTypes.BOOLEAN, defaultValue: false }
});

const IsActivationUser = sequelize.define("isActivationUser", {
  userId: { type: DataTypes.INTEGER },
  activationLink: { type: DataTypes.UUID },
  activation: { type: DataTypes.BOOLEAN, defaultValue: false },
});

const Photo = sequelize.define("Photo", {
  path: { type: DataTypes.STRING },
  problemId: { type: DataTypes.INTEGER },
});

const Video = sequelize.define("Video", {
  path: { type: DataTypes.STRING },
  problemId: { type: DataTypes.INTEGER },
})

const Problem = sequelize.define("Problem", {
  tittle: {
    type: DataTypes.STRING,
  },
  userId: {
    type: DataTypes.INTEGER,
  },
  date: {
    type: DataTypes.DATE,
    defaultValue: Date.now(),
  },
  description: {
    type: DataTypes.STRING,
  },
});

const BannedUser = sequelize.define("BannedUser", {
  userId: { type: DataTypes.INTEGER },
  reason: { type: DataTypes.STRING },
})

User.hasOne(BannedUser, {
  foreignKey: "userId"
})
BannedUser.belongsTo(User, {
  foreignKey: "userId"
})

User.hasOne(IsActivationUser, {
  onDelete: "cascade",
  foreignKey: "userId",
});
IsActivationUser.belongsTo(User, {
  foreignKey: "userId",
});

User.hasMany(Problem, {
  foreignKey: "userId",
  onDelete: "cascade",
});
Problem.belongsTo(User, {
  foreignKey: "userId",
});

Problem.hasMany(Photo, {
  foreignKey: "problemId",
  onDelete: "cascade",
});
Photo.belongsTo(Problem, {
  foreignKey: "problemId",
});

Problem.hasMany(Video, {
  foreignKey: "problemId",
  onDelete: "cascade",
});
Video.belongsTo(Problem, {
  foreignKey: "problemId",
});

//Synchronizing();

module.exports = {
  sequelize,
  User,
  IsActivationUser,
  Problem,
  Photo,
  Video,
  BannedUser
};

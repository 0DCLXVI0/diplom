import { createContext, useState } from "react";
const Context = createContext()

function ContextProvider({ children }) {
    const [isUserAuth, setIsUserAuth] = useState(localStorage.getItem("accessToken") ? true : false);
    const [userARole, setUserARole] = useState(parseInt(localStorage.getItem("userARole")))

    return <Context.Provider value={{ isUserAuth, setIsUserAuth, userARole, setUserARole }}>
        {children}
    </Context.Provider>
}

export { ContextProvider, Context }
module.exports = async function (req, res, next) {
  try {
    const accessToken = req.headers.authorization;
    if (!accessToken)
      return res.status(201).send({ message: "Пользователь неавторизован" });
    next();
  } catch (err) {
    console.log(err);
  }
};

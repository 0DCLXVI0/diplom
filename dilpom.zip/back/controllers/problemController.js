const verifyToken = require("../services/verifyToken");
const fs = require("fs")
const { Problem, User, Photo, Video } = require("../db/db");
const path = require("path");

const problemController = {
  addProblem: async function (req, res) {
    try {
      const { file: files } = req.files;
      const { tittle, description } = req.body;
      const { userId } = verifyToken(req);
      const problem = await Problem.create({
        tittle,
        description,
        userId,
      });
      if (files) {
        files.forEach(async file => {
          const type = file.mimetype.split("/")[0]
          if (type === "image") await Photo.create({ path: file.filename, problemId: problem.id })
          else if (type === "mp4") await Video.create({ path: file.filename, problemId: problem.id })
        })
      }
      return res.status(200).json({ message: "Проблема опубликована" });
    } catch (err) {
      console.log(err);
    }
  },
  getProblems: async function (req, res) {
    try {
      const problems = await Problem.findAll({
        attributes: ["tittle", "date", "id"],
        include: [
          { model: User, attributes: ["nickname"] },
          { model: Photo, attributes: ["path"] },
        ],
      });
      return res.status(200).json(problems);
    } catch (err) {
      console.log(err);
    }
  },
  getProblem: async function (req, res) {
    try {
      const { problemId } = req.params
      if (!problemId)
        return res
          .status(201)
          .json({ message: "Такой проблемы не существует" });
      const problem = await Problem.findByPk(problemId, {
        include: [
          { model: Photo, attributes: ["id", "path"] },
          { model: Video, attributes: ["id", "path"] },
          { model: User, attributes: ["nickname"] }
        ]
      })
      return res.status(200).json(problem);
    } catch (err) {
      console.log(err);
    }
  },
};

module.exports = problemController;

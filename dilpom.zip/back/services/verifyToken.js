const jwt = require("jsonwebtoken");

module.exports = function (req) {
    const bearerToken = req.headers.authorization;
    const accessToken = bearerToken.split(" ")[1];
    return jwt.verify(accessToken, process.env.JWT_ACCESS_TOKEN);
}
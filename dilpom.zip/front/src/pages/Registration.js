import RegistrationForm from "../components/RegistrationForm"
import { registrationAPI } from "../http/userAPI"

function Registration() {
    return <RegistrationForm tittle="Регистрация" callback={registrationAPI} />
}

export default Registration
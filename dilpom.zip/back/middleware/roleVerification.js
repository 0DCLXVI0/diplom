const { User } = require("../db/db");
const verifyToken = require("../services/verifyToken");

module.exports = function (role) {
    try {
        return async function (req, res, next) {
            const { userId } = verifyToken(req);
            const user = await User.findByPk(userId)
            if (user.role < role)
                return res.
                    status(201).
                    json({ message: "У вас недостаточно прав" })
            next()
        }
    } catch (err) {
        console.log(err)
    }
}